# Shopymalls — Stap 14.2 Explore

Deze versie bouwt voort op Home en koppelt de onderste navigatie aan een echte Explore-screen.

## Explore bevat
- Search malls, stores, brands & deals
- Filters: Malls / Stores / Deals / Events
- Explore Malls
- Categorieën
- Today's Deals
- Eenvoudige kaartweergave met malls in de omgeving

## Start
npm install
npx expo start
