Shopymalls Step 14.13 — Advertising

Toegevoegd:
- Campaign builder
- Campaign goals
- Channel selection
- Targeting preview
- Budget + duration
- Estimated reach
- Launch flow

Start:
npm install
npx expo start

Volgende stap: 14.14 Analytics.
