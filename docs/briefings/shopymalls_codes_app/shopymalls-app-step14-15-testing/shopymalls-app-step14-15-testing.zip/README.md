Shopymalls Step 14.15 — Testing

Toegevoegd:
- MVP QA checklist
- Functionele flow check
- iPhone / Android / Web checklist
- Release gate
- Pilot readiness
- Volgende stap: Jakarta pilot

Start:
npm install
npx expo start

Let op: dit is een test- en releasechecklist in de app. Volledige geautomatiseerde device testing en CI/CD komen later.
