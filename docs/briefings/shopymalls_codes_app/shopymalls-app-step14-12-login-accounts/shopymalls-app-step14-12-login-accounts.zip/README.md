# Shopymalls — Stap 14.12 Login & Accounts

Toegevoegd:
- Supabase email/password login
- Account registreren
- Rolkeuze: Shopper / Retailer / Mall
- Session herstel bij app-start
- Uitloggen
- Basis voorbereiding voor Google login

Vereist:
- EXPO_PUBLIC_SUPABASE_URL
- EXPO_PUBLIC_SUPABASE_ANON_KEY

Start:
npm install
npx expo start

Let op: social/Apple login en server-side rolbeveiliging worden verder aangescherpt in volgende stappen.
