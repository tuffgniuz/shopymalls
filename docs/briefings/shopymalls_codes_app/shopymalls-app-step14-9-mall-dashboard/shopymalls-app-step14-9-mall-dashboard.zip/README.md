Shopymalls Step 14.9 — Home + Explore + Mall Profile + Store Profile + Deal Page + Saved + Profile + Retailer Dashboard + Mall Dashboard.
Start: npm install && npx expo start