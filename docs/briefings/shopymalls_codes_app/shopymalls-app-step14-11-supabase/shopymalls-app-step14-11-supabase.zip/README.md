# Shopymalls — Stap 14.11 Supabase

De app is voorbereid op een echte Supabase-backend.

## 1. Supabase-project maken
Maak een Supabase-project aan en kopieer:
- Project URL
- anon public key

## 2. Database
Open in Supabase:
SQL Editor → New query

Voer `supabase/001_initial_schema.sql` volledig uit.

## 3. Environment
Kopieer `.env.example` naar `.env` en vul de twee Supabase-waarden in.

## 4. Installeren
npm install
npx expo start

## Wat is nu voorbereid?
- profiles
- malls
- stores
- store_staff
- products
- deals
- deal_products
- events
- favorites
- campaigns
- advertisements
- notifications
- subscriptions
- payments
- analytics_events

De app gebruikt in deze stap nog voorbeelddata. De volgende stap is 14.12: login & accounts en daarna vervangen we de voorbeelddata scherm voor scherm door Supabase-data.
