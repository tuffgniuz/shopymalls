Shopymalls Step 14.7 — Home + Explore + Mall Profile + Store Profile + Deal Page + Saved + Profile.
Start: npm install && npx expo start