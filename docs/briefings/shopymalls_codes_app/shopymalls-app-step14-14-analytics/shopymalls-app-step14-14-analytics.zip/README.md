Shopymalls Step 14.14 — Analytics

Toegevoegd:
- Periode: 7D / 30D / 90D
- Platform analytics
- Retailer analytics
- Mall analytics
- Campaign analytics
- KPI cards
- Performance charts
- Top categories, malls, stores and campaigns

Start:
npm install
npx expo start

Volgende stap: 14.15 Testen.
