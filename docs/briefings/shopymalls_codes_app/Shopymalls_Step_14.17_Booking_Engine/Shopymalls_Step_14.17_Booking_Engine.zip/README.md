Shopymalls Step 14.16 — Pilot Jakarta

Toegevoegd:
- Pilot preparation
- Pilot onboarding
- Live pilot monitoring
- Customer journey metrics
- Pilot review
- Go / improve / pause decision point

Doel:
Een gecontroleerde eerste marktvalidatie in Jakarta met echte shoppers, retailers en minimaal één mall.

Start:
npm install
npx expo start
